<?php
/**
 * Standalone PHP Bridge for Sampath Bank Paycorp Integration
 * Location: slia.lk
 * 
 * This script handles:
 * 1. Initiation: Main App -> Bridge -> Bank
 * 2. Callback: Bank -> Bridge -> Main App
 */

// --- Configuration ---
// These values MUST match the main application's .env file
$secret_key = 'x0AmSSU0SbSdRAI0'; 
$client_id = '14005990';
$auth_token = '64509e4d-f919-4028-84db-0325afee6889';

// Paycorp Production Endpoint
$paycorp_endpoint = 'https://secure.paycorp.lk/rest/service/proxy';

// Main Application Callback (Fallback)
$main_app_callback = 'https://sliaannualsessions.lk/api/conference/payment-callback';

header('Content-Type: application/json');

// --- 1. Handle Callback/Redirect from Bank ---
if (isset($_GET['mode']) && $_GET['mode'] === 'callback') {
    // Get parameters from redirect (GET or POST)
    $params = array_merge($_GET, $_POST);
    
    // Construct data for Main App
    $callback_data = [
        'transaction_id' => $params['reqid'] ?? $params['txnReference'] ?? '',
        'reference' => $params['clientRef'] ?? '',
        'status' => (isset($params['status']) && ($params['status'] === 'success' || $params['status'] === 'completed')) ? 'completed' : 'failed',
        'amount' => $params['amount'] ?? 0,
        'bank_reference' => $params['bankReference'] ?? '',
        'payment_method' => $params['paymentMethod'] ?? '',
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    // Sign the data for Main App
    ksort($callback_data);
    $data_string = implode('|', array_values($callback_data));
    $signature = hash_hmac('sha256', $data_string, $secret_key);
    $callback_data['signature'] = $signature;
    
    // Build redirect URL back to Main App
    $query = http_build_query($callback_data);
    $redirect_url = $main_app_callback . '?' . $query;
    
    header('Location: ' . $redirect_url);
    exit;
}

// --- 2. Handle Initiation Request ---
$raw_input = file_get_contents('php://input');
$data = json_decode($raw_input, true);

if (!$data) {
    // If not JSON, maybe it's just a test GET request
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        echo json_encode(['success' => true, 'message' => 'SLIA Payment Bridge is active.']);
        exit;
    }
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid or missing JSON payload']);
    exit;
}

// Verify Signature from Main App
$received_signature = $data['signature'] ?? '';
unset($data['signature']); 

ksort($data);
$data_string = implode('|', array_values($data));
$expected_signature = hash_hmac('sha256', $data_string, $secret_key);

if (!hash_equals($expected_signature, $received_signature)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Security check failed: Signature mismatch']);
    exit;
}

// Initiate with Paycorp (Sampath Bank)
$paycorp_payload = [
    'clientId' => $client_id,
    'authToken' => $auth_token,
    'transactionAmount' => [
        'totalAmount' => round($data['amount'] * 100), // Amount in cents
        'currency' => 'LKR'
    ],
    'clientRef' => $data['reference'],
    'comment' => 'Conference Registration - ' . $data['name'],
    // Point the return URL back to THIS bridge with mode=callback
    'returnUrl' => 'https://slia.lk/pay-bridge.php?mode=callback',
    'tokenize' => false
];

$ch = curl_init($paycorp_endpoint);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($paycorp_payload));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($response && $http_code === 200) {
    $result = json_decode($response, true);
    
    echo json_encode([
        'success' => true,
        'payment_url' => $result['paymentUrl'] ?? null,
        'transaction_id' => $result['txnReference'] ?? null,
        'message' => 'Payment initiated via slia.lk bridge'
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Paycorp Gateway Error: ' . ($response ?: 'Connection Timeout'),
        'debug_info' => $http_code
    ]);
}
